Gantt Chart plugin for Mantis.
By Alain D'EURVEILHER (alain.deurveilher@gmail.com)


This plugin is based on the Mantis Graph plugin. The jpgraph library is required to make it work.
The Gantt Chart plugin for mantis indeed uses the jpgraph_gantt.php lib.

TODO: Complete the README file.
TODO: Create the documentation.
TODO: manage the gantt chart boundaries (should limit all the graphs to a max of 80 rows and 80 weeks for performance issues.)
